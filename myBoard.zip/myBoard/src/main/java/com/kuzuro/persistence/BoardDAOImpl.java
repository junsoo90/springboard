package com.kuzuro.persistence;

import java.util.List;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import com.kuzuro.domain.BoardVO;
import com.kuzuro.domain.Criteria;
import com.kuzuro.domain.FileVO;
import com.kuzuro.domain.ReplyVO;
import com.kuzuro.domain.SearchCriteria;

@Repository
public class BoardDAOImpl implements BoardDAO {

	// 留덉씠諛뷀떚�뒪 
	@Inject
	private SqlSession sql;
	
	// 留ㅽ띁 
	private static String namespace = "com.kuzuro.mappers.boardMapper";
		
	// �옉�꽦
	@Override
	public void write(BoardVO vo) throws Exception {
		sql.insert(namespace + ".write", vo);
	}

	// 議고쉶
	@Override
	public BoardVO read(int bno) throws Exception {
		return sql.selectOne(namespace + ".read", bno);
	} 
	
	// �닔�젙
	@Override
	public void update(BoardVO vo) throws Exception {
		sql.update(namespace + ".update", vo);
	}

	// �궘�젣
	@Override
	public void delete(int bno) throws Exception {
		sql.delete(namespace + ".delete", bno);
	}

	// 紐⑸줉
	@Override
	public List<BoardVO> list() throws Exception {
		return sql.selectList(namespace + ".list");
	}

	// 紐⑸줉 + �럹�씠吏�
	@Override
	public List<BoardVO> listPage(Criteria cri) throws Exception {
		return sql.selectList(namespace + ".listPage", cri);
	}

	// 寃뚯떆臾� 珥� 媛��닔
	@Override
	public int listCount() throws Exception {
		return sql.selectOne(namespace + ".listCount");
	}

	// 紐⑸줉 + �럹�씠吏� + 寃��깋
	@Override
	public List<BoardVO> listSearch(SearchCriteria scri) throws Exception {
		System.out.println("search keyword = " + scri.getKeyword());
	
		return sql.selectList(namespace + ".listSearch", scri);
	}

	// 寃��깋 寃곌낵 媛��닔
	@Override
	public int countSearch(SearchCriteria scri) throws Exception {
		return sql.selectOne(namespace + ".countSearch", scri);
	}

	// �뙎湲� 議고쉶
	@Override
	public List<ReplyVO> readReply(int bno) throws Exception {
		return sql.selectList(namespace + ".readRpley", bno);
	}

	public int fileInsert(FileVO file) throws Exception{
		return sql.insert(namespace + ".fileInsert", file);
	}
	
	public FileVO fileDetail(int bno) throws Exception{
		return sql.selectOne(namespace + ".fileDetail", bno);
	}
	
	
}